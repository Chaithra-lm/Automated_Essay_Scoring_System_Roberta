import torch
from transformers import RobertaForSequenceClassification, RobertaTokenizer
from torch.utils.data import DataLoader, Dataset
from flask import Flask, request, render_template, jsonify
import random
import torch.nn as nn

# Define the custom transformer model class
class CustomTransformerModel(nn.Module):
    def __init__(self, transformer_model: RobertaForSequenceClassification, num_labels=6):  # Update num_labels
        super(CustomTransformerModel, self).__init__()
        self.transformer = transformer_model
        self.transformer.classifier.out_proj = nn.Linear(self.transformer.config.hidden_size, num_labels)  # Update classifier output size

    def forward(self, input_ids, attention_mask=None):
        attention_mask = (input_ids != tokenizer.pad_token_id).type(input_ids.type()) if attention_mask is None else attention_mask
        logits = self.transformer(input_ids, attention_mask=attention_mask)[0]
        return logits

# Load the tokenizer and the model
pretrained_model_name = "roberta-base"
saved_model_path = "roberta_finetuned.pth"

tokenizer = RobertaTokenizer.from_pretrained(pretrained_model_name)
base_model = RobertaForSequenceClassification.from_pretrained(pretrained_model_name)

# Wrap the base model with the custom class
model = CustomTransformerModel(transformer_model=base_model, num_labels=6)  # Update num_labels
model.load_state_dict(torch.load(saved_model_path))

# Set device
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)

def preprocess(text, tokenizer, max_seq=1024):
    sys_prompt = "Please read the following essay and assign a score of 1,2,3,4,5,6 where 6 is the best. Output only a single number with no explanation.\n\n"
    formatted_sample = sys_prompt + text
    tokenized_sample = tokenizer(formatted_sample, padding=True, return_tensors="pt", truncation=True, max_length=max_seq)
    return tokenized_sample

def score_function(text, tokenizer, model):
    with torch.no_grad():
        tokenized_sample = preprocess(text, tokenizer, max_seq=2048)
        input_ids = tokenized_sample['input_ids'].to(device)
        attention_mask = tokenized_sample['attention_mask'].to(device)
        outputs = model(input_ids, attention_mask=attention_mask)
        logits = outputs if not isinstance(outputs, dict) else outputs.logits
        _, predicted = torch.max(logits, dim=1)
        predicted_score = random.choice([2, 3, 4, 5, 6])  # Override model output with a random choice
        return predicted_score

def get_feedback(score):
    if score==2:
        return "You need to work hard to use grammar, overall structure, real-time grammar, punctuation, and spelling checks "
    elif score == 3:
        return "You still need to improve your grammar and overall structure."
    elif score == 4:
        return "Good use of words and no major errors."
    elif score == 5:
        return "Nice writing skills!"
    elif score == 6:
        return "You are a fantastic essay writer!"
    return "Score out of range."

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/score', methods=['POST'])
def create_task():
    data = request.json
    essay = data.get('text', '')
    score = score_function(essay, tokenizer, model)
    feedback = get_feedback(score)
    print("==> Input: ", essay[:10])
    print("==> score: ", score)
    return jsonify({'score': score, 'feedback': feedback})

if __name__ == '__main__':
    app.run(host="0.0.0.0", debug=True, port=8000)
